Read docs/handoff-2026-08-18b.md FIRST and verify the git state it describes
(the N12/N40 triage batch #381-#382 on top of 26f29133 - if the chain does
not match, stop and say so). This session runs in **#380 BUDGET MODE - the
scope is PINNED, do not widen it.**

PICK ONE (two at most). Both are BUILD items whose triage is already DONE -
do NOT re-derive it, read the row and build:

① **N12 - BUILD** (blocked until I answer the dial in handoff §3). A
restoring user must not be nudged to back up. TWO legs, both named with
file:line in DECISIONS #381 + the worklist R4 row. Leg 2 is one line
(seed backupReminderTimestamp in LaunchRestorePage.onRestore). Leg 1 needs
my dial: skip onboarding entirely on restore, or carry restore provenance
to the tail as a C#→WebView PUSH (never a new ixian: verb) and start the
tail at the join step.

② **N40 - BUILD** (blocked until I run the zero-device check in handoff §2).
Fix shape = docs/n40-triage-connecting.md §5, three small C# parts. ⚠ part 2
is a product dial (show the update notice AND the offline state together, or
keep one arm) - do not guess it.

③ If BOTH are still blocked on my answers: do the queued triage items
**N10 · N15 · N39** instead - triage only, same deliverable shape as the
N40 doc.

NOTHING ELSE. Do not touch N57 (Core-side, my protocol run pending), the
deferred pile, or anything in the archived 17g handoff §6.

ECONOMY RULES (hard): smoke as bookends only - baseline once (expect 1947/4)
and final once (state the new number) - plus ONE batched mutation-proof run
for any new pins. ONE Opus review round at the end, and only if C#/money/data
paths changed; no r2/r3 unless it finds a MAJOR. No agent fan-outs. Standing
set otherwise unchanged: cloud twin · verify against code (#215) · bundle
before shells · locale pipeline + i18n-lint + pseudo + i18n-overflow-audit
only IF strings changed · DECISIONS rows at decision time · security gate row
· tarball delivery + updated handoff + F5 checklist (short - only the legs
this session touched). I commit.
