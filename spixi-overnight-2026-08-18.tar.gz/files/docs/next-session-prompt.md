Read `docs/handoff-2026-08-19f.md` FIRST, then `DECISIONS.md` rows #399–#406.

The previous session was overnight and unattended. It landed one large
UNCOMMITTED batch: the four #391 F5 fixes, the permanent community door,
**AND-7 full bleed** (the Android status-bar strip stops existing), the locale
tail, the offline→online update check, and the update-notice scope — plus two
review rounds that found 6 MAJOR and fixed them. Smoke 1992 → **2052 / the same
4 known pre-existers**. Nothing was compiled and nothing was F5'd.

**If Damir has not yet F5'd and committed that batch, do NOT start new work.**
Help him land it: `docs/f5-checklist-2026-08-18-overnight.md` has the exact
build and git commands, and §6 tells him how to read the on-screen probe that
answers the two questions the cloud could not (the real Android inset numbers,
and whether F-5's late empty states are the gate or the data).

**Once it is committed, the next batch is N71** — the theme push-vs-reload
round, the biggest open red. It was deliberately not stacked into the overnight
batch (DECISIONS #406) so that a red on device points at one thing. Root cause
is already recorded in handoff 19c §2: the revived OS-flip path RELOADS where
the working explicit-pick path PUSHES, and `settings.html` has no `setTheme`
handler at all, along with eleven other shells. Diff the two paths rather than
inventing a third (#385's lesson), and verify at source before building (#215).

Standing rules that this batch re-earned the hard way, and that apply to yours:
pin the SITE the behaviour runs through and MUTATE it before believing it — the
overnight batch shipped three pins that matched their own comments and one
security pin that could not fail; and a fallback edit is not a copy change until
`extract-strings` has run, because the generated dictionary shadows the
component fallback at runtime.
