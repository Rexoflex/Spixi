# BE cutover — the Ixian-Core reply carrier, and two latent defects beside it

**LANGUAGE RULE: ASD-STE100 Simplified Technical English.** See `CLAUDE.md`.

**Status: HELD OUT of the 2026-08-20 batch on Damir's call. Nothing here is applied.**
Reference point: Ixian-Core `097341a` (`xcore-0.9.8k`).

This document holds three asks against `Ixian-Core`. **Only ask 1 is about reply-to.**
Asks 2 and 3 are pre-existing defects the reply-to work walked into; they are independent
of the feature and, in our reading, should land whether or not reply-to does.

The exact patch is at the end of this file and ships beside it as
`ixian-core-reply-carrier.patch`. It applies cleanly to `097341a` with
`git apply` from the Ixian-Core root.

---

## Why this is one repo away and not a package away

`Ixian-Core` is a **shared project compiled into Spixi from source** —
`Spixi/Spixi.csproj:292` imports `IXICore.projitems` and `SPIXI.sln` references
`IXICore.shproj`. So this is not a dependency bump and not a release; it is a second
working tree that has to be committed with the Spixi side. That is also why it is being
held: it is the one part of the batch that touches a repo we do not own.

---

## Ask 1 — a reply reference on the chat payload (feature M1)

**The problem.** Read at source against `097341a`: there is no reply field anywhere.
`StreamMessage` (v0 and v1) has none; `SpixiMessage` carries only
type / data / channel / groupAddress / groupSenderAddress; `SpixiMessageCode` has no reply
code; `FriendMessage`, the persisted record, has none. A `chat` payload is
`Encoding.UTF8.GetBytes(str)` — raw text, no envelope — so the only place to put a
reference without a Core change is inside the message body, which would render as visible
junk on any client that does not strip it.

**The shape, and why it is small.** `SpixiMessageCode.chatStream` (53) already has a typed
payload — `ChatStreamMessage(MessageId, Message, Sequence, IsStream)` — registered in
`SpixiMessageObjectMap`. So this is **one appended field there**, not a new message code.

### 1a. `Streaming/Models/ChatStreamMessage.cs` — the wire field

Adds `public byte[]? ReplyToId { get; set; }` and a fifth optional constructor argument.

Two properties matter and both are deliberate:

* **It is written LAST in `getBytes()` and ONLY when it is set.** A message that is not a
  reply therefore serialises **byte-identically** to the pre-M1 format. The wire does not
  move for traffic that has no reply.
* **The parser reads it behind an `offset < data.Length` bounds check inside a `try`.**
  The constructor already read a fixed sequence and never asserted it consumed the buffer,
  so an older build ignores the trailing bytes and shows a plain message.

⚠ **Please do not add a length assertion to that constructor.** The trailing-byte tolerance
*is* the backward-compatibility contract. An assertion would turn every old-client
round-trip into a hard failure.

Hostile input is handled at three points, because the tail is peer-controlled:

1. the declared length is bounded against the remaining buffer **before** the allocation
   (`ReadIxiBytes` does `new byte[len]` first, so a peer could otherwise declare ~2 GB
   with no payload — the `catch` would swallow it, but the transient allocation is an
   OS-kill risk on a phone);
2. the value is clamped to `CoreConfig.maxMessageIdSize`;
3. anything that still throws degrades to `ReplyToId = null`. **A throw here would reach
   the receive path and lose the whole message**, so failing closed would mean failing
   lossy.

### 1b. `Streaming/Friends/FriendMessage.cs` — persistence

Adds `public byte[]? replyToId = null;`, read under the existing append-tolerant
`if (m.Position < m.Length)` guard and written last. That is exactly how `transactionId`,
`payableDataLen`, `reactions`, `sent`, `errorSending` and `sequence` were each added — this
is the sixth field to ride the pattern.

Both directions are safe: an older build reading a newer record stops after `sequence` and
ignores the tail; a newer build reading an older record leaves `replyToId` null.

One deliberate choice worth your eye: a record with **no** reply writes a 4-byte zero
rather than nothing, so the slot stays positional and a seventh field can be appended later
without ambiguity. Cost is 4 bytes per stored message. Say the word if you would rather it
wrote nothing.

### 1c. `Streaming/Friends/FriendList.cs` — threading it through

Two lines. The first copies the wire value onto the new record. The second is on the
stream-**replace** arm: without it, editing a message keeps whatever reference the *first*
version had, so an edit that adds or removes a reply renders the wrong quote — or none.

---

## Ask 2 — `sendChatStreamMessage` passes a NULL StreamMessage id (LATENT DEFECT)

`Streaming/CoreStreamProcessor.cs:2216`. Not about reply-to.

```
sendSpixiMessage(friend, spixi_message, null, null, true, true, true, false);
                                              ^^^^ the id
```

`sendChatMessage`, five lines above, passes `friend_message.id`. This passes nothing, so
`StreamMessage` generates its own id.

**Why that breaks.** The receiver acknowledges with `sendReceivedConfirmation(friend,
message.id)` — the **envelope** id — and `handleMsgReceived` on the sender looks the record
up by **`FriendMessage.id`**. With a generated envelope id those two can never match, so
**every delivery and read tick is lost** for anything sent through this function.

It is invisible today only because `sendChatStreamMessage` is written and never called. It
becomes live the moment anything uses `chatStream` — which reply-to would.

The fix is one argument: `chat_stream_message.MessageId`.

---

## Ask 3 — `ChatStreamMessage` measures its size in two different units (LATENT DEFECT)

Also not about reply-to.

* `getBytes()` checks `Message.Length` — **UTF-16 code units**
* the constructor checks `messageBytes.bytes.Length` — **UTF-8 bytes**

`CoreConfig.maxChatMessageSize` is 64000.

**Failure.** About 21,400 Chinese or Japanese characters is 64,002 UTF-8 bytes and 21,400
characters. Every check on the sender passes and the message goes out. On the receiver
`new ChatStreamMessage(data)` throws, the exception unwinds into the swallowing `try` in
the receive path, the message is never stored, **no receipt is sent**, and the sender's
bubble sits on the clock forever. A group relay forwards the raw payload, so every member
drops it.

The fix computes the UTF-8 bytes once and checks *that*. Callers still gate on characters,
which is stricter for ASCII and is the legacy contract; this only makes the backstop stop
lying. ⚠ It is a tightening, so it can refuse something a caller previously let through —
worth your read even though we could not find a live caller it changes.

---

## What Spixi looks like without this

The FE is fully built and gated off, and there are exactly **two seams** in
`Spixi/Pages/Chat/SingleChatPage.xaml.cs`, both marked `★ THE SEAM`:

| | Today (stock Core) | After this lands |
|---|---|---|
| `onSend` | sends `SpixiMessageCode.chat` through `sendChatMessage`, exactly as before the batch; a reply target is parsed, logged and dropped | build a `ChatStreamMessage` with `ReplyToId` and send it through `sendChatStreamMessage` when a reply is attached |
| the per-message push | `string reply_to = "";` | `message.replyToId != null && message.replyToId.Length > 0 ? Crypto.hashToString(message.replyToId) : ""` |

Nothing can reach either path today: the `reply` capability is declared by no `setCaps`
call, so the shell cannot create a reply at all.

⚠ **One decision that must survive the cutover.** The first cut moved **every** chat
message onto `chatStream`. That is unsafe and the dates say why: code 53 landed
2026-05-30, i.e. **after** the `spixi-0.9.19` release. An older peer has no case for it —
and its `requireRcvConfirmation` switch has a `default:` arm that **sends the receipt
anyway**. So the message vanishes on the receiver while the sender shows a delivered tick,
and a group whose owner or relay is older goes silent for everyone. Nothing negotiates it:
`StreamCapabilities` has no chat bit and nothing consults `protocolVersion`.

So the message code must be chosen **per message** — no reply → `chat`, a reply →
`chatStream` — unless BE would rather add a capability bit (bit 64 is free and commented
out) and negotiate it properly. **That is the one open question in this document.**

---

## The patch

Ships beside this file as `ixian-core-reply-carrier.patch`. From the Ixian-Core root:

```
git apply ixian-core-reply-carrier.patch
```

```diff
diff --git a/Streaming/CoreStreamProcessor.cs b/Streaming/CoreStreamProcessor.cs
index de8e4fc..6fc83f6 100644
--- a/Streaming/CoreStreamProcessor.cs
+++ b/Streaming/CoreStreamProcessor.cs
@@ -2213,7 +2213,13 @@ namespace IXICore.Streaming
             SpixiMessage spixi_message = new SpixiMessage(SpixiMessageCode.chatStream, chat_stream_message.getBytes(), channel);
             byte[] spixi_msg_bytes = spixi_message.getBytes();
 
-            sendSpixiMessage(friend, spixi_message, null, null, true, true, true, false);
+            // ★ The StreamMessage id MUST be the chat message id, exactly as
+            // sendChatMessage passes friend_message.id. The receiver acknowledges with
+            // sendReceivedConfirmation(friend, message.id) — the STREAM message id —
+            // and the sender then looks the record up by FriendMessage id. With a
+            // generated id those two never match and every delivery/read tick is lost.
+            // This function was written and never called, so the defect was latent.
+            sendSpixiMessage(friend, spixi_message, null, chat_stream_message.MessageId, true, true, true, false);
 
             return true;
         }
diff --git a/Streaming/Friends/FriendList.cs b/Streaming/Friends/FriendList.cs
index 2605dde..51ecb8f 100644
--- a/Streaming/Friends/FriendList.cs
+++ b/Streaming/Friends/FriendList.cs
@@ -243,6 +243,7 @@ namespace IXICore.Streaming
             }
             FriendMessage friend_message = new FriendMessage(id, chat_stream_message.Message, timestamp, local_sender, type, set_sender_address, sender_nick, chat_stream_message.Sequence);
             friend_message.payableDataLen = payable_data_len;
+            friend_message.replyToId = chat_stream_message.ReplyToId;   // M1 reply-to (additive)
 
             List<FriendMessage>? messages = friend.getMessages(channel);
             if(messages == null)
@@ -286,6 +287,11 @@ namespace IXICore.Streaming
                             tmp_msg.message = chat_stream_message.Message;
                             tmp_msg.sequence = chat_stream_message.Sequence;
                             tmp_msg.timestamp = timestamp;
+                            // M1 audit MINOR-4: a REPLACE carries its own reply reference.
+                            // Without this the record kept the reference the FIRST version
+                            // had, so an edit that added or removed a reply rendered the
+                            // wrong quote — or none.
+                            tmp_msg.replyToId = chat_stream_message.ReplyToId;
                         }
                         else if (chat_stream_message.Sequence == tmp_msg.sequence + 1)
                         {
diff --git a/Streaming/Friends/FriendMessage.cs b/Streaming/Friends/FriendMessage.cs
index 46bcddd..ca54b1c 100644
--- a/Streaming/Friends/FriendMessage.cs
+++ b/Streaming/Friends/FriendMessage.cs
@@ -62,6 +62,14 @@ namespace IXICore.Streaming
 
         public int sequence = 0;
 
+        /// <summary>
+        /// M1 reply-to: the id of the message this message replies to, or null.
+        /// Appended LAST in getBytes() and read behind the existing append-tolerant
+        /// `if (m.Position &lt; m.Length)` guard, which is exactly how transactionId,
+        /// reactions, sent, errorSending and sequence were each added.
+        /// </summary>
+        public byte[]? replyToId = null;
+
         public FriendMessage(byte[]? id, string msg, long time, bool local_sender, FriendMessageType t, Address? sender_address = null, string sender_nick = "", int sequence = 0)
         {
             _id = id;
@@ -170,6 +178,16 @@ namespace IXICore.Streaming
                         {
                             sequence = reader.ReadInt32();
                         }
+                        if (m.Position < m.Length)
+                        {
+                            // M1 reply-to. A record written by an older build simply
+                            // ends here and replyToId stays null.
+                            int reply_id_len = reader.ReadInt32();
+                            if (reply_id_len > 0 && reply_id_len <= CoreConfig.maxMessageIdSize)
+                            {
+                                replyToId = reader.ReadBytes(reply_id_len);
+                            }
+                        }
                     }
                     catch (Exception)
                     {
@@ -237,6 +255,17 @@ namespace IXICore.Streaming
                     writer.Write(sent);
                     writer.Write(errorSending);
                     writer.Write(sequence);
+
+                    // M1 reply-to, appended last (see the field comment).
+                    if (replyToId != null && replyToId.Length > 0 && replyToId.Length <= CoreConfig.maxMessageIdSize)
+                    {
+                        writer.Write(replyToId.Length);
+                        writer.Write(replyToId);
+                    }
+                    else
+                    {
+                        writer.Write((int)0);
+                    }
                 }
                 return m.ToArray();
             }
diff --git a/Streaming/Models/ChatStreamMessage.cs b/Streaming/Models/ChatStreamMessage.cs
index 09209f7..242ff46 100644
--- a/Streaming/Models/ChatStreamMessage.cs
+++ b/Streaming/Models/ChatStreamMessage.cs
@@ -23,12 +23,24 @@ namespace IXICore.Streaming.Models
         public int Sequence { get; set; }
         public bool IsStream { get; set; }
 
-        public ChatStreamMessage(byte[]? messageId, string message, int sequence, bool isStream)
+        /// <summary>
+        /// M1 reply-to: the id of the message this message replies to, or null.
+        /// ADDITIVE and OPTIONAL. It is written LAST in getBytes() and ONLY when it
+        /// is set, so a message that is not a reply serialises byte-identically to
+        /// the pre-M1 format. The parser reads it behind a bounds check, so a build
+        /// that does not know the field ignores the trailing bytes and shows a plain
+        /// message. ★ Do not add a length assertion to the parser — that tolerance
+        /// IS the backward-compatibility contract.
+        /// </summary>
+        public byte[]? ReplyToId { get; set; }
+
+        public ChatStreamMessage(byte[]? messageId, string message, int sequence, bool isStream, byte[]? replyToId = null)
         {
             MessageId = messageId;
             Message = message;
             Sequence = sequence;
             IsStream = isStream;
+            ReplyToId = replyToId;
         }
 
         public ChatStreamMessage(byte[] data)
@@ -57,11 +69,51 @@ namespace IXICore.Streaming.Models
 
             IsStream = data[offset] == 1;
             offset += 1;
+
+            // M1 reply-to, OPTIONAL TAIL. Everything below is peer-controlled, so it
+            // must never be able to drop a legitimate message: an absent, malformed or
+            // over-long reference degrades to "no reply" and the message still shows.
+            // A throw here would reach the receive path and lose the whole message.
+            if (offset < data.Length)
+            {
+                try
+                {
+                    // Audit MINOR-6: ReadIxiBytes allocates `new byte[len]` BEFORE any
+                    // bound is applied, so a peer could declare ~2 GB with no payload.
+                    // The catch below would swallow the OutOfMemoryException, but the
+                    // transient allocation is an OS-kill risk on a phone. Refuse a
+                    // declared length that cannot fit in what is left of the buffer.
+                    var declared = data.GetIxiVarUInt(offset);
+                    if (declared.num > (ulong)(data.Length - offset - declared.bytesRead))
+                    {
+                        throw new Exception("Reply id length exceeds the remaining buffer.");
+                    }
+                    var replyBytes = data.ReadIxiBytes(offset);
+                    if (replyBytes.bytes != null
+                        && replyBytes.bytes.Length > 0
+                        && replyBytes.bytes.Length <= CoreConfig.maxMessageIdSize)
+                    {
+                        ReplyToId = replyBytes.bytes;
+                    }
+                    offset += replyBytes.bytesRead;
+                }
+                catch (Exception)
+                {
+                    ReplyToId = null;
+                }
+            }
         }
 
         public byte[] getBytes()
         {
-            if (Message.Length > CoreConfig.maxChatMessageSize)
+            // Audit MAJOR-2: the parser checks UTF-8 BYTES (:59) while this checked
+            // UTF-16 CHARACTERS, so a long non-ASCII body passed every sender check and
+            // then threw inside the receiver's parser — the message lost, no receipt
+            // sent, the sender's bubble stuck on the clock forever. Measure what the
+            // reader measures. (Callers still gate on characters, which is stricter for
+            // ASCII and is the legacy contract; this is the backstop that used to lie.)
+            byte[] messageUtf8 = Encoding.UTF8.GetBytes(Message);
+            if (messageUtf8.Length > CoreConfig.maxChatMessageSize)
             {
                 throw new Exception("Chat message exceeds maximum size limit.");
             }
@@ -71,7 +123,7 @@ namespace IXICore.Streaming.Models
             var messageIdBytes = MessageId.GetIxiBytes();
             totalSize += messageIdBytes.Length;
 
-            var messageBytes = Encoding.UTF8.GetBytes(Message).GetIxiBytes();
+            var messageBytes = messageUtf8.GetIxiBytes();
             totalSize += messageBytes.Length;
 
             var sequenceBytes = Sequence.GetIxiVarIntBytes();
@@ -79,6 +131,19 @@ namespace IXICore.Streaming.Models
 
             totalSize += 1; // IsStream
 
+            // M1: written ONLY when this is a reply, so a plain message keeps the
+            // exact pre-M1 byte layout.
+            byte[]? replyIdBytes = null;
+            if (ReplyToId != null && ReplyToId.Length > 0)
+            {
+                if (ReplyToId.Length > CoreConfig.maxMessageIdSize)
+                {
+                    throw new Exception("Chat reply id exceeds maximum size limit.");
+                }
+                replyIdBytes = ReplyToId.GetIxiBytes();
+                totalSize += replyIdBytes.Length;
+            }
+
             byte[] result = new byte[totalSize];
             int offset = 0;
 
@@ -94,6 +159,12 @@ namespace IXICore.Streaming.Models
             result[offset] = IsStream ? (byte)1 : (byte)0;
             offset += 1;
 
+            if (replyIdBytes != null)
+            {
+                replyIdBytes.CopyTo(result, offset);
+                offset += replyIdBytes.Length;
+            }
+
             return result;
         }
     }
```
