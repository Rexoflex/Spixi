﻿using IXICore;
using IXICore.Meta;
using IXICore.Streaming;
using Microsoft.Maui.Controls;
using Spixi;
using SPIXI.Interfaces;
using SPIXI.Lang;
using SPIXI.Meta;
using System;
using System.Linq;
using System.Text;
using System.Threading;

namespace SPIXI.VoIP
{

    public class VoIPManager
    {
        public static byte[]? currentCallSessionId { get; private set; }
        public static Friend currentCallContact { get; private set; }
        public static bool currentCallAccepted { get; private set; }
        public static bool currentCallCalleeAccepted { get; private set; }
        public static string? currentCallCodec { get; private set; }
        public static long currentCallStartedTime { get; private set; }

        static IAudioPlayer? audioPlayer = null;
        static IAudioRecorder? audioRecorder = null;

        static long lastPacketReceivedTime = 0;
        static Thread? lastPacketReceivedCheckThread = null;
        private static readonly object lastPacketReceivedLock = new object();

        static bool currentCallInitiator = false;
        public static long currentCallInitiated { get; private set; } = 0;

        public static bool isInitiated()
        {
            if(currentCallSessionId != null)
            {
                return true;
            }
            return false;
        }

        public static void initiateCall(Friend friend)
        {
            if (currentCallSessionId != null)
            {
                return;
            }

            SSpixiPermissions.requestAudioRecordingPermissions();

            currentCallSessionId = Guid.NewGuid().ToByteArray();
            currentCallContact = friend;
            currentCallCalleeAccepted = false;
            currentCallAccepted = true;
            currentCallCodec = null;
            currentCallInitiator = true;
            currentCallInitiated = Clock.getTimestamp();

            string codecs = String.Join("|", SSpixiCodecInfo.getSupportedAudioCodecs());

            var sm = StreamProcessor.sendAppRequest(friend, "spixi.voip", currentCallSessionId, Encoding.UTF8.GetBytes(codecs), "spixi.voip");
            Node.addMessageWithType(currentCallSessionId, FriendMessageType.voiceCall, friend.walletAddress, 0, "", true, null, 0, false);
            // C18/C19 (#265): BROADCAST — stack-last is HomePage under the #225 overlay
            // model, so an outgoing call started FROM A CHAT showed no bar at all.
            SpixiContentPage.broadcastCallBar(currentCallSessionId, SpixiLocalization._SL("global-call-dialing") + " " + friend.nickname + "...", 0);
            
            aquirePowerLocks();
            SPlatformUtils.startDialtone(DialtoneType.dialing);
            startRingTimeout();   // #265: an unanswered call must not ring forever
        }

        public static bool onReceivedCall(Friend friend, byte[] session_id, byte[] data)
        {
            if (currentCallSessionId != null)
            {
                if (!currentCallSessionId.SequenceEqual(session_id))
                {
                    StreamProcessor.sendAppRequestReject(friend, session_id);
                }
                return false;
            }

            currentCallSessionId = session_id;
            currentCallContact = friend;
            currentCallCalleeAccepted = true;
            currentCallAccepted = false;
            currentCallCodec = null;
            currentCallInitiator = false;
            currentCallInitiated = Clock.getTimestamp();

            string codecs_str = Encoding.UTF8.GetString(data);

            string[] codecs = codecs_str.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var codec in codecs)
            {
                if (SSpixiCodecInfo.isCodecSupported(codec))
                {
                    currentCallCodec = codec;
                    break;
                }
            }
            if (currentCallCodec == null)
            {
                Logging.error("Unsupported audio codecs: " + codecs_str);
                rejectCall(session_id);
                return false;
            }
            aquirePowerLocks();
            // #334 AND-11: pre-request the mic at RING time (messenger practice) so
            // the grant dialog resolves while the phone is still ringing instead of
            // inside the answer tap (see the acceptCall gate). Loop MINOR-6: this
            // runs on the STREAM thread — Android's RequestPermissions must launch
            // from the main thread or it's OEM-flaky/unsupported.
            if (!SSpixiPermissions.hasAudioRecordingPermissions())
            {
                Microsoft.Maui.ApplicationModel.MainThread.BeginInvokeOnMainThread(() =>
                {
                    SSpixiPermissions.requestAudioRecordingPermissions();
                });
            }
            SPlatformUtils.startRinging();
            startRingTimeout();   // #265: the incoming overlay auto-clears on the SAME budget
            return true;
        }

        private static void aquirePowerLocks()
        {
            SPowerManager.AquireLock("screenDim");
            SPowerManager.AquireLock("partial");
            SPowerManager.AquireLock("wifi");
            SPowerManager.AquireLock("proximityScreenOff");
        }

        private static void releasePowerLocks()
        {
            SPowerManager.ReleaseLock("screenDim");
            SPowerManager.ReleaseLock("partial");
            SPowerManager.ReleaseLock("wifi");
            SPowerManager.ReleaseLock("proximityScreenOff");
        }

        private static void startVoIPSession()
        {
            if (currentCallCodec == null)
            {
                Logging.error("No current call codec!");
                return;
            }

            SPlatformUtils.stopDialtone();
            SPlatformUtils.stopRinging();
            try
            {
                audioPlayer = SAudioPlayer.Instance();
                audioPlayer.start(currentCallCodec);

                audioRecorder = SAudioRecorder.Instance();
                audioRecorder.start(currentCallCodec);
                audioRecorder.setOnSoundDataReceived((data) =>
                {
                    StreamProcessor.sendAppData(currentCallContact, currentCallSessionId, data);
                });
                currentCallStartedTime = Clock.getTimestamp();
                startLastPacketReceivedCheck();
            }
            catch(Exception e)
            {
                Logging.error("Exception occured while starting VoIP session: " + e);
                hangupCall(currentCallSessionId, true);
            }
        }

        private static void endVoIPSession()
        {
            SPlatformUtils.stopRinging();

            /* ★ 3.14 (Damir on device 2026-08-21): "despite being a missed call the
             * notification says 'Incoming call'."
             *
             * It is not wrong copy — it is STALE copy. The row is posted while the call is
             * genuinely incoming and then outlives the call, because nothing ever took it
             * down. NOTIF-4 made that more visible: the call keeps its own id instead of
             * being overwritten by the next message, so the lie persists until tapped.
             *
             * ⚠ MY FIRST FIX WAS WRONG, and Damir caught it on device: I CANCELLED the row.
             * That deleted the missed call instead of correcting it — "the missed call row
             * doesn't remain in the notification tray, it disappears". A missed call is
             * exactly the kind of thing a notification tray exists to hold on to; the
             * verdict said to REWORD it and I over-simplified to a cancel.
             *
             * So it is RE-POSTED under the same id with missed-call copy. Same id means it
             * REPLACES the stale row rather than stacking beside it, and it is call-flavoured
             * so it can never take down a message row. Silent (`alert: false`) — the ringtone
             * already happened, and a second buzz for a call you just missed is noise.
             *
             * ⚠ Only when the call was NOT answered. `acceptCall` cancels instead: once you
             * are talking, there is nothing left to tell you. */
            try
            {
                var endedWith = currentCallContact;
                if (endedWith != null && endedWith.walletAddress != null)
                {
                    int callNotifId = SPIXI.Meta.SNotificationPrefs.notificationIdFor(endedWith.walletAddress, true);
                    if (currentCallAccepted || currentCallCalleeAccepted || currentCallInitiator)
                    {
                        // Answered, or we placed it — nothing was missed, so take the row down.
                        SPushService.cancelNotification(callNotifId);
                    }
                    else
                    {
                        // ★ A genuinely MISSED incoming call. Correct the row; do not delete it.
                        SPushService.showLocalNotification(
                            callNotifId,
                            "Spixi",
                            SpixiLocalization._SL("notification-missed-call") ?? "Missed call",
                            endedWith.walletAddress.ToString(),
                            false,      // alert: silent — the ring already happened
                            FriendList.getUnreadMessageCount(),
                            "call");
                    }
                }
            }
            catch (Exception e)
            {
                Logging.warn("endVoIPSession: could not update the call notification: " + e.Message);
            }

            try
            {
                if (audioPlayer != null)
                {
                    audioPlayer.Dispose();
                    audioPlayer = null;
                }
            }
            catch (Exception e)
            {
                audioPlayer = null;
                Logging.error("Exception occured in endVoIPSession 1: " + e);
            }

            try
            {
                if (audioRecorder != null)
                {
                    audioRecorder.Dispose();
                    audioRecorder = null;
                }
            }
            catch (Exception e)
            {
                audioRecorder = null;
                Logging.error("Exception occured in endVoIPSession 2: " + e);
            }

            if (currentCallContact != null)
            {
                bool callAccepted = currentCallAccepted && currentCallCalleeAccepted;
                long callDuration = currentCallStartedTime > 0 ? Clock.getTimestamp() - currentCallStartedTime : 0;
                var fm = currentCallContact.endCall(currentCallSessionId, currentCallAccepted && currentCallCalleeAccepted, callDuration, currentCallInitiator);
                if (fm == null)
                {
                    Logging.warn("Cannot end call, no message with session ID exists.");
                } else
                {
                    var tmp_messages = currentCallContact.getMessages(0);
                    if (callAccepted == true && tmp_messages.Last() != fm)
                    {
                        fm.message = callDuration.ToString();
                        Node.addMessageWithType(currentCallSessionId, FriendMessageType.voiceCallEnd, currentCallContact.walletAddress, 0, fm.message, currentCallInitiator, null, 0);
                    }
                    else
                    {
                        fm.type = FriendMessageType.voiceCallEnd;
                        if (callAccepted)
                        {
                            fm.message = callDuration.ToString();
                        }
                        IxianHandler.localStorage.requestWriteMessages(currentCallContact.walletAddress, 0);
                        UIHelpers.insertMessage(currentCallContact, 0, fm);
                    }
                }

            }

            currentCallSessionId = null;
            currentCallContact = null;
            currentCallCalleeAccepted = false;
            currentCallAccepted = false;
            currentCallCodec = null;
            currentCallStartedTime = 0;
            currentCallInitiated = 0;
            lock (lastPacketReceivedLock)
            {
                lastPacketReceivedTime = 0;
                if (lastPacketReceivedCheckThread != null)
                {
                    try
                    {
                        lastPacketReceivedCheckThread.Interrupt();
                    }
                    catch (Exception)
                    {
                    }
                    lastPacketReceivedCheckThread = null;
                }
            }
            try
            {
                releasePowerLocks();
            }
            catch (Exception e)
            {
                Logging.error("Exception occured in endVoIPSession 3: " + e);
            }
            SpixiContentPage.broadcastHideCallBar();   // C18 (#265): every surface drops bar + ring
        }

        public static void acceptCall(byte[] session_id)
        {
            /* ⚠ AUDIT MINOR (3.14): clear the "Incoming call" row on ANSWER too. Cancelling
             * only at end-of-call left it standing for the whole conversation — the user
             * answers from the in-app overlay and never taps the notification, so SetAutoCancel
             * never fires. Stale copy for the length of every answered call. */
            try
            {
                var acceptedWith = currentCallContact;
                if (acceptedWith != null && acceptedWith.walletAddress != null)
                {
                    SPushService.cancelNotification(
                        SPIXI.Meta.SNotificationPrefs.notificationIdFor(acceptedWith.walletAddress, true));
                }
            }
            catch (Exception e)
            {
                Logging.warn("acceptCall: could not clear the call notification: " + e.Message);
            }
            if (!hasSession(session_id))
            {
                return;
            }

            if (currentCallAccepted)
            {
                return;
            }

            // #334 AND-11: the permission request is ASYNC — execution used to fall
            // straight into sendAppRequestAccept + startVoIPSession with the OS
            // dialog still up; without RECORD_AUDIO the AudioRecord ctor throws →
            // the session catch hangs up → the peer saw accept-then-instant-hangup
            // (≈ decline) and the user's "Allow" landed on a dead call. GATE the
            // accept instead: no permission → fire the request and DON'T accept —
            // the call keeps ringing (45s budget), a second Accept lands after the
            // grant (the ring-time pre-request in onReceivedCall makes this rare).
            if (!SSpixiPermissions.hasAudioRecordingPermissions())
            {
                Microsoft.Maui.ApplicationModel.MainThread.BeginInvokeOnMainThread(() =>
                {
                    SSpixiPermissions.requestAudioRecordingPermissions();
                });
                // ★ Loop MAJOR-1: the FE ring overlay one-shots + dismisses itself on
                // the Accept tap — without a re-render the user faces a BLANK,
                // back-swallowing, still-ringing cover whenever no OS dialog appears
                // (permanently-denied mic). Re-arm the app-request refresh so the next
                // UI tick (~2s cadence, Node.updateUILoop) re-presents the ring on
                // EVERY path — dialog or no dialog. A denied user still can't accept
                // (correct — no mic) but can always Decline; an explain-affordance
                // (copy + settings deep-link) = Damir dial, DECISIONS #335.
                UIHelpers.refreshAppRequests = true;
                return;
            }

            currentCallAccepted = true;
            StreamProcessor.sendAppRequestAccept(currentCallContact, session_id, Encoding.UTF8.GetBytes(currentCallCodec));
            startVoIPSession();
            if (currentCallContact != null)
            {
                // C18 (#265): broadcast — every surface that rang swaps its ring for the
                // bar (the FE drops the local ring on displayCallBar), so no stale
                // Decline survives to kill the live call (C18b(a)).
                SpixiContentPage.broadcastCallBar(currentCallSessionId, SpixiLocalization._SL("global-call-in-call") + " - " + currentCallContact.nickname, currentCallStartedTime);
            }
        }

        public static void onAcceptedCall(byte[] session_id, byte[] data)
        {
            if (!hasSession(session_id))
            {
                return;
            }

            if(currentCallCalleeAccepted)
            {
                return;
            }

            currentCallCodec = Encoding.UTF8.GetString(data);
            currentCallCalleeAccepted = true;
            startVoIPSession();
            if (currentCallContact == null)
                return;
            SpixiContentPage.broadcastCallBar(currentCallSessionId, SpixiLocalization._SL("global-call-in-call") + " - " + currentCallContact.nickname, currentCallStartedTime);   // C18
        }

        public static void rejectCall(byte[] session_id)
        {
            if (!hasSession(session_id))
            {
                return;
            }
            // C18b(a) (#265): NEVER reject an ALREADY-ACCEPTED call. A surface that rang
            // and missed the answer (pre-C18 delivery gap, or a page presented mid-ring)
            // could still fire ixian:appReject → this method tore down the LIVE call.
            // Now a decline on an accepted session is ignored; the FE also drops its ring
            // on displayCallBar, so both halves of the hazard are closed.
            if (currentCallAccepted && currentCallCalleeAccepted)
            {
                Logging.warn("rejectCall ignored: the call is already accepted (stale UI).");
                return;
            }
            StreamProcessor.sendAppRequestReject(currentCallContact, session_id);
            endVoIPSession();
        }

        public static void onRejectedCall(byte[] session_id)
        {
            if (!hasSession(session_id))
            {
                return;
            }
            SPlatformUtils.startDialtone(DialtoneType.busy);
            SpixiContentPage.broadcastHideCallBar();   // C18
            endVoIPSession();
        }

        public static void hangupCall(byte[] session_id, bool error = false)
        {
            if (session_id == null)
            {
                session_id = currentCallSessionId;
            }
            // C18b(b) (#265): a STALE call bar's Hang-up used to run with no session —
            // sendAppEndSession(currentCallContact = null, …) on a dead call. Guard it:
            // no live session → just make sure every surface drops its bar.
            if (session_id == null || !hasSession(session_id))
            {
                Logging.warn("hangupCall ignored: no live session (stale UI) — clearing the bars.");
                SpixiContentPage.broadcastHideCallBar();
                return;
            }
            if (error)
            {
                SPlatformUtils.startDialtone(DialtoneType.error);
            }
            else
            {
                SPlatformUtils.stopDialtone();
            }
            StreamProcessor.sendAppEndSession(currentCallContact, session_id);
            SpixiContentPage.broadcastHideCallBar();   // C18
            endVoIPSession();
        }

        public static void onHangupCall(byte[] session_id)
        {
            if (!hasSession(session_id))
            {
                return;
            }
            SPlatformUtils.stopDialtone();
            SpixiContentPage.broadcastHideCallBar();   // C18
            endVoIPSession();
        }

        public static void onData(byte[] session_id, byte[] data)
        {
            if (!hasSession(session_id))
            {
                return;
            }
            if (audioPlayer != null)
            {
                audioPlayer.write(data);
                lastPacketReceivedTime = Clock.getTimestamp();
            }
        }

        public static bool hasSession(byte[] session_id)
        {
            if(currentCallSessionId != null && session_id != null && currentCallSessionId.SequenceEqual(session_id))
            {
                return true;
            }
            return false;
        }

        private static void startLastPacketReceivedCheck()
        {
            lock (lastPacketReceivedLock)
            {
                lastPacketReceivedTime = Clock.getTimestamp();
                if (lastPacketReceivedCheckThread != null)
                {
                    try
                    {
                        lastPacketReceivedCheckThread.Interrupt();
                        lastPacketReceivedCheckThread.Join();
                    }
                    catch (Exception)
                    {
                    }
                    lastPacketReceivedCheckThread = null;
                }
                lastPacketReceivedCheckThread = new Thread(lastPacketReceivedCheck);
                lastPacketReceivedCheckThread.IsBackground = true;
                lastPacketReceivedCheckThread.Start();
            }
        }

        /* ————— #265 (Damir): RING TIMEOUT ————————————————————————————————————————
         * An unanswered call used to ring FOREVER on both ends (his F5: "the incoming
         * call overlay persists"). Industry practice is ~45s (Telegram/WhatsApp), and
         * BOTH ends must use the SAME budget so the caller's "No answer" and the
         * callee's "Missed call" land together.
         *   caller (initiator) → hangupCall → end-session packet + "No answer" log
         *   callee            → endVoIPSession ONLY (no reject packet — the call was
         *                       MISSED, not declined; the caller's own timeout is what
         *                       tells them) → the ring clears, the message logs missed.
         * The thread self-exits the moment the call connects (currentCallStartedTime),
         * is answered, or the session ends. */
        public const int RING_TIMEOUT_SECONDS = 45;
        static Thread? ringTimeoutThread = null;

        private static void startRingTimeout()
        {
            byte[]? sid = currentCallSessionId;
            if (sid == null)
            {
                return;
            }
            ringTimeoutThread = new Thread(() =>
            {
                try
                {
                    while (true)
                    {
                        Thread.Sleep(1000);
                        byte[]? live = currentCallSessionId;
                        if (live == null || !live.SequenceEqual(sid))
                        {
                            return;                      // session ended or replaced
                        }
                        if (currentCallStartedTime != 0)
                        {
                            return;                      // connected — the media watchdog owns it now
                        }
                        if (Clock.getTimestamp() - currentCallInitiated < RING_TIMEOUT_SECONDS)
                        {
                            continue;
                        }
                        Logging.info("VoIP ring timeout ({0}s) — ending the unanswered call.", RING_TIMEOUT_SECONDS);
                        if (currentCallInitiator)
                        {
                            hangupCall(sid);             // tells the peer + logs "No answer"
                        }
                        else
                        {
                            // review MINOR-3 (TOCTOU): re-check under the same rule
                            // hangupCall uses — the session could have ended (and a NEW
                            // call been accepted) between the snapshot and here.
                            if (!hasSession(sid))
                            {
                                return;
                            }
                            endVoIPSession();            // missed, NOT declined (no reject packet)
                        }
                        return;
                    }
                }
                catch (ThreadInterruptedException) { }
                catch (Exception e)
                {
                    Logging.error("Exception in ring timeout: " + e);
                }
            });
            ringTimeoutThread.IsBackground = true;
            ringTimeoutThread.Start();
        }

        private static void lastPacketReceivedCheck()
        {
            try
            {
                while (true)
                {
                    lock (lastPacketReceivedLock)
                    {
                        if (currentCallStartedTime == 0 || lastPacketReceivedTime + 10 <= Clock.getTimestamp())
                        {
                            break;
                        }
                    }
                    Thread.Sleep(1000);
                }
            }
            catch (ThreadInterruptedException)
            {

            }
            catch (Exception e)
            {
                Logging.error("Exception occured in lastPacketReceivedCheck: " + e);
            }
            finally
            {
                lock (lastPacketReceivedLock)
                {
                    lastPacketReceivedCheckThread = null;
                }
                hangupCall(currentCallSessionId, true);
            }
        }

        public static void setVolume(float volume)
        {
            if(audioPlayer != null)
            {
                audioPlayer.setVolume(volume);
            }
        }
    }
}
