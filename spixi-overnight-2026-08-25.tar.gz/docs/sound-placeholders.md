# The four in-app effect sounds — PLACEHOLDERS

★ **These four files are placeholders, generated 2026-08-22 at Damir's request**
("pick some for me to try"). They exist so the SND-1/SND-2 wiring can be *heard* and
judged on a device. They are not a design decision and nothing depends on their content.

| File | Fires on | Shape |
|---|---|---|
| `message_sent.mp3` | an outgoing chat message | one short blip, 0.18 s — the quietest of the four, because it only confirms an action the user just took |
| `message_received.mp3` | an incoming chat message | a two-note RISE, 0.29 s — told apart from *sent* by shape, not only by pitch |
| `tx_sent.mp3` | an outgoing payment | two warmer, lower notes, 0.37 s — a payment is a heavier event than a message |
| `tx_received.mp3` | an incoming payment | the only three-note ascending figure, 0.52 s — money arriving is the one event worth a small reward |

All four: mono, 44.1 kHz, 96 kbps, peak **−12.5 dBFS**, 4 ms attack and a 5 ms tail fade
so nothing clicks. Synthesized sine + one harmonic with an exponential decay —
`docs/sound-placeholders-gen.py` regenerates them exactly.

## Replacing them

Drop real files over these, **keeping the same four names**, and nothing else changes:
`SSounds` addresses them by path (`Spixi/Meta/SSounds.cs`), the csproj glob
(`MauiAsset Include="Resources\Raw\**"`) picks them up by folder, and no code moves.

Two things worth matching so the set still behaves as one:
* keep the peak near **−12 dBFS** — the four call sounds beside them are much louder, and
  an effect that competes with a ringtone is the thing users turn off first;
* keep them **under ~0.6 s** — these fire on every message, and the sound must be over
  before the next one starts.

⚠ The app is silent and safe without any of them: `SSounds.play` fails soft on a missing
asset, which was verified on iOS hardware in the 2026-08-21 pass.
