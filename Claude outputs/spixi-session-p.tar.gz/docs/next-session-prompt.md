# Next session — paste this

Repo: `C:\Users\Damir\Claude\Projects\Spixi Rework Of Frontend\Spixi`, branch
`redesign/frontend`. Ixian-Core sibling frozen at `097341a`, read-only.

**Read `docs/handoff-2026-09-06.md` FIRST.** Then DECISIONS #800, #801, #802.

**Item 0 — verify the baseline in a clean clone before touching anything.** Expect exactly:
bundle 320 · shells 18 · smoke **BASELINE OK 4360 / the 3 known (#136 · M5 · B3)** WITH the
sibling (4359 without) · locales **784 ALL CLEAN** · i18n-lint ✓ (6 dev exemptions) · pseudo
9/9 · cs-syntax 138 + 1 · `extract-strings`/`build-shells`/`build-legal-docs` `--check` all ✓ ·
`strip-release --check` OK (gate 1) · `smoke-packaged` OK (gate 2, 4359). Any difference → STOP
and say so before building.

**Item 1 — the numbers.** Session P shipped both levers and the loop said CLEAN, but the
verdict on whether they WORKED is on the phone, not in the suite. `docs/f5-checklist-session-p.md`
§3 has the capture plan. The three questions:

1. Did the open get faster? (`attach spare=1 tap=…` vs the Session O `ctor tap=…`)
2. **Did the chats list pay for it?** (`chats-after-close frames n= drop= max=`, BEFORE vs
   AFTER — if `drop=`/`max=` rose, the warm moves or gates on list idle)
3. Did the batch collapse the eval queue? (`chat batch n= json= t=` and the shell's
   `batch=1`, against #796's drain→painted 96–126 ms)

Do not build anything on top of these levers until those numbers exist (#294).

**Then, in Damir's order:** whatever he ranks next. Candidates already designed or deferred:
B2 (prepend on load-more — the shell contract is complete, the C# half is not), B4 (the load
window, his dial), ⛔ #779 (parked with the lead), the `[CDPERF]` retirement (one batch, nine
pieces, pinned as a set).

**Rules that bind the work:** mutate in FULL tar copies, never `cp -al`, and run the COPY's
scripts · bundle BEFORE shells · the closing number is measured AFTER the last suite edit ·
every pin declares `stripCode` or raw and asserts a PROPERTY (#771) · a behavioural pin that
stubs the function under test proves nothing · a comment stating an invariant the code does not
enforce is a defect (#772) · file:line is a searchable anchor (#773) · `onNavigating` cancels
FIRST and re-allows only `file:` (#797) · **a refusal, an enumeration or a sweep written from
the author's list is not yet a pin (#798, and the rule that closed the #802 loop)** · the commit
is Damir's in GitHub Desktop, never `git add -A`, nothing pushes from the container.

**If a #46 loop runs: run it on Opus.** Session P's rounds 1–12 ran on the session's own model
and the thirteenth round, on Opus, still found a MAJOR the other twelve had walked past.
