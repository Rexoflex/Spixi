SPIXI — overnight batch, 2026-08-18 (DECISIONS #399-#406)
=========================================================

WHAT THIS IS
  116 changed/new files from an unattended cloud session, on top of commit
  679b917 (branch redesign/frontend). Nothing was compiled and nothing was
  F5'd — no MAUI workload in the container and no device.

HOW TO APPLY
  Extract `files/` OVER your repo root. It preserves paths, so:

      tar xzf spixi-overnight-2026-08-18.tar.gz
      cp -r files/. /path/to/your/Spixi/      (or extract straight over it)

  `overnight-batch.patch` is the same delta as a git patch if you prefer
  `git apply`. It covers TRACKED files only — the two NEW docs are in `files/`.

READ IN THIS ORDER
  1. docs/handoff-2026-08-19f.md          <- the state, and section 2 is the
                                             honest "could not verify" list
  2. docs/f5-checklist-2026-08-18-overnight.md
                                          <- exact build + git commands, the
                                             test legs, and the commit message
  3. DECISIONS.md rows #399-#406          <- every decision, at the time it was made
  4. docs/next-session-prompt.md          <- for the next session

WHAT YOU MUST REBUILD YOURSELF
  Everything generated is ALREADY rebuilt in here and is part of the delta:
      src/demo/spixi.iife.js · src/demo/strings.iife.js
      src/strings/*.json · *.js (incl. en-us) · src/strings/draft/*.todo.json
      Spixi/Resources/Raw/html/*  (18 shells + bundle + strings + base css)
  Re-run the generators anyway before you commit — a green smoke run does not
  prove the generators work (#383). The exact order is in the F5 checklist §0.
  ** bundle BEFORE shells, always. **

  C# changed in 9 files, so WIPE Spixi\obj and Spixi\bin before building.

STATE
  smoke  1992 -> 2052 pass, the same 4 known pre-existers (#136 #149(3) M5 B3)
  gates  verify-locales ALL CLEAN · i18n-lint OK · pseudo 9/9 · overflow NO BREAKERS
  review 3 disjoint auditors, then a break-my-verdict pass over the fixes.
         6 MAJOR found and fixed. 17 mutations run to prove the new pins can fail.

THE TWO THINGS I MOST WANT BACK FROM THE F5
  1. Whether the in-call HANG-UP control is fully visible on Android
     (checklist 1.6) — that is the audit's MAJOR-1 and it has never run.
  2. One screenshot of the on-screen probe line (checklist section 6). It
     carries the real Android inset numbers AND the boot timeline that decides
     whether the late empty states are the gate or the data.
