﻿using IXICore;
using IXICore.Meta;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Xaml;
using Microsoft.Maui.Storage;
using Spixi;
using SPIXI.Interfaces;
using SPIXI.Lang;
using SPIXI.Meta;
using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Web;

namespace SPIXI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LaunchRestorePage : SpixiContentPage
	{
		public LaunchRestorePage ()
		{
			InitializeComponent ();
            NavigationPage.SetHasNavigationBar(this, false);
            loadPage(webView, "intro_restore.html");
        }

        private void onNavigated(object sender, WebNavigatedEventArgs e)
        {

        }

        private void onNavigating(object sender, WebNavigatingEventArgs e)
        {
            string current_url = HttpUtility.UrlDecode(e.Url);

            if (current_url.Equals("ixian:back", StringComparison.Ordinal))
            {
                popPageAsync();
            }
            else if (current_url.Equals("ixian:selectfile", StringComparison.Ordinal))
            {
                onSelectFile();
            }
            else if (current_url.Contains("ixian:restore:"))
            {
                string[] split = current_url.Split(new string[] { "ixian:restore:" }, StringSplitOptions.None);
                if (split.Count() < 1)
                {
                    e.Cancel = true;
                    Utils.sendUiCommand(this, "removeLoadingOverlay");
                    Utils.sendUiCommand(this, "showPasswordError");
                    return;
                }

                /* ★ W14 (#348, Damir's call): the SAME guard LaunchCreatePage already has.
                 * Delete-account now routes to the welcome screen and deliberately KEEPS
                 * the wallet, so a live wallet can sit behind onboarding for the first
                 * time. Create refuses in that state (LaunchCreatePage:162-169); Restore
                 * had no equivalent check, so it was the one door that would have run
                 * over the wallet the user had just chosen to keep.
                 * Same honest alert, same shape, same strings as Create. */
                if (IxianHandler.getWalletList().Count > 0)
                {
                    /* D-7 (#371): RESTORE gets its OWN copy. The Create message
                     * ("restart to continue with it") answers a question the
                     * restoring user did not ask and names no way forward — one
                     * dangerous door had become zero doors. This one names the
                     * path out (findings §D-7, correct regardless of D-6). */
                    displaySpixiAlert(SpixiLocalization._SL("intro-restore-walletexists-title") ?? "Account already on this device",
                        SpixiLocalization._SL("intro-restore-walletexists-text") ?? "An account already exists on this device. To use it, restart Spixi. To restore a different account: restart Spixi, open Account, tap Delete wallet, then open Restore again.",
                        SpixiLocalization._SL("global-dialog-ok") ?? "OK");
                    e.Cancel = true;
                    Utils.sendUiCommand(this, "removeLoadingOverlay");
                    return;
                }

                string password = split[1]; // Todo: secure this
                if(!onRestore(password))
                {
                    e.Cancel = true;
                    Utils.sendUiCommand(this, "removeLoadingOverlay");
                }
            }
            else
            {
                // Otherwise it's just normal navigation
                e.Cancel = false;
                return;
            }
            e.Cancel = true;

        }

        // Shows a file picker to select the wallet file
        private async void onSelectFile()
        {
            byte[] _data = null;
            // #334 L7: the shell previously displayed the STAGING filename
            // ("wallet.ixi.tmp") — surface the picked file's real display name
            // (SpixiImageData.name, filled by every platform SFilePicker) instead;
            // the staging path stays the fallback when a platform leaves it null.
            string pickedName = null;
            try
            {
                SpixiImageData fileData = await SFilePicker.PickFileAsync();
                if (fileData == null)
                    return; // User canceled file picking

                pickedName = fileData.name;

                var stream = fileData.stream;
                _data = new byte[stream.Length];
                stream.Read(_data, 0, (int)stream.Length);
            }
            catch (Exception ex)
            {
                Logging.error("Exception choosing file: " + ex.ToString());
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                displaySpixiAlert(SpixiLocalization._SL("intro-restore-file-error-title"), SpixiLocalization._SL("intro-restore-file-selecterror-text"), SpixiLocalization._SL("global-dialog-ok"));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                return;
            }

            if (_data == null)
            {
                await displaySpixiAlert(SpixiLocalization._SL("intro-restore-file-error-title"), SpixiLocalization._SL("intro-restore-file-readerror-text"), SpixiLocalization._SL("global-dialog-ok"));
                return;
            }

            string docpath = Config.spixiUserFolder;
            string filepath = Path.Combine(docpath, Config.walletFile + ".tmp");
            try
            {
                File.WriteAllBytes(filepath, _data);
            }
            catch (Exception ex)
            {
                Logging.error("Exception caught in process: {0}", ex);
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                displaySpixiAlert(SpixiLocalization._SL("intro-restore-file-error-title"), SpixiLocalization._SL("intro-restore-file-writeerror-text"), SpixiLocalization._SL("global-dialog-ok"));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                return;
            }

            // #334 L7: push the picked display name (shell baseName() handles a bare
            // filename unchanged); the staging path only when no name was available.
            Utils.sendUiCommand(this, "setUploadedFileName", pickedName ?? filepath);
        }

        // Attempt to restore the wallet
        private bool onRestore(string pass)
        {
            Preferences.Default.Remove("onboardingComplete");
            Preferences.Default.Remove("lockenabled");
            Preferences.Default.Remove("waletpass");

            /* ★ N12 (#383, Damir 2026-08-18): "when restoring an account, we shouldn't
             * nudge the user to back up immediately, since it's restoring from backup."
             * TWO nudges fired on a fresh restore, and they are independent:
             *   leg 1 — the onboarding tail's FIRST step is the backup nudge. Restore and
             *           create both clear onboardingComplete, so HomePage could not tell
             *           them apart. This pref carries the provenance; HomePage reads it
             *           just before it builds OnboardPage and the tail opens on the JOIN
             *           step instead. Damir's dial: the join step STAYS for restorers.
             *   leg 2 — displayBackupReminder fires on the first tick whenever
             *           backupReminderTimestamp is absent, which it is on a fresh install.
             *           Seeding it here starts the 30-day period (Config.backupReminder)
             *           at the restore. Existing key, existing period — nothing new. */
            Preferences.Default.Set("onboardingFromRestore", true);
            Preferences.Default.Set("backupReminderTimestamp", Clock.getTimestamp().ToString());

            SpixiLocalization.addCustomString("OnboardingComplete", "false");

            Preferences.Default.Set("walletpass", pass);

            string source_path = Path.Combine(Config.spixiUserFolder, Config.walletFile) + ".tmp";
            if(!File.Exists(source_path))
            {
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                displaySpixiAlert(SpixiLocalization._SL("intro-restore-file-error-title"), SpixiLocalization._SL("intro-restore-file-selecterror-text"), SpixiLocalization._SL("global-dialog-ok"));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                return false;
            }
            if (restoreAccountFile(source_path, pass))
            {
                return true;
            }
            restoreWalletFile(source_path, pass);
            return true;
        }

        private bool restoreAccountFile(string source_path, string pass)
        {
            // TODO add file header
            string tmpDirectory = Path.Combine(Config.spixiUserFolder, "tmp_zip");
            try
            {
                if(Directory.Exists(tmpDirectory))
                {
                    Directory.Delete(tmpDirectory, true);
                }
                Directory.CreateDirectory(tmpDirectory);
                byte[] decrypted = CryptoManager.lib.decryptWithPassword(File.ReadAllBytes(source_path), pass, true);
                if (decrypted == null)
                {
                    Directory.Delete(tmpDirectory, true);
                    return false;
                }
                byte[] header = UTF8Encoding.UTF8.GetBytes("SPIXIACCB1");
                for(int i = 0; i < header.Length; i++)
                {
                    if(decrypted[i] != header[i])
                    {
                        Directory.Delete(tmpDirectory, true);
                        return false;
                    }
                }
                byte[] zipFileBytes = decrypted.Skip(header.Length).ToArray();
                File.WriteAllBytes(source_path, zipFileBytes);
                ZipFile.ExtractToDirectory(source_path, tmpDirectory);
                string tmpWalletFile = Path.Combine(tmpDirectory, Config.walletFile);
                WalletStorage ws = new WalletStorage(tmpWalletFile);
                if (!ws.verifyWallet(tmpWalletFile, pass))
                {
                    Directory.Delete(tmpDirectory, true);
                    Utils.sendUiCommand(this, "showPasswordError");
                    // Remove overlay
                    Utils.sendUiCommand(this, "removeLoadingOverlay");
                    return false;
                }
                Directory.Delete(Path.Combine(Config.spixiUserFolder, "Acc"), true);
                Directory.Move(Path.Combine(tmpDirectory, "Acc"), Path.Combine(Config.spixiUserFolder, "Acc"));
//                Directory.Delete(Path.Combine(Config.spixiUserFolder, "Chats"), true);
//                Directory.Move(Path.Combine(tmpDirectory, "Chats"), Path.Combine(Config.spixiUserFolder, "Chats"));
                if (File.Exists(Path.Combine(tmpDirectory, "account.ixi")))
                {
                    File.Move(Path.Combine(tmpDirectory, "account.ixi"), Path.Combine(Config.spixiUserFolder, "account.ixi"));
                }
                if (File.Exists(Path.Combine(tmpDirectory, "avatar.jpg")))
                {
                    File.Move(Path.Combine(tmpDirectory, "avatar.jpg"), Path.Combine(Config.spixiUserFolder, "avatar.jpg"));
                }
                File.Move(Path.Combine(tmpDirectory, "wallet.ixi"), Path.Combine(Config.spixiUserFolder, "wallet.ixi"));

                Node.loadWallet();
                Directory.Delete(tmpDirectory, true);
                File.Delete(source_path);
                IxianHandler.localStorage.accountRestored = true;
                Navigation.PushAsync(HomePage.Instance(true), Config.defaultXamarinAnimations);
                removePage(this);
                return true;
            }catch(Exception e)
            {
                Logging.warn("Exception occured while trying to restore account file: " + e);
                Directory.Delete(tmpDirectory, true);
            }
            return false;
        }

        private bool restoreWalletFile(string source_path, string pass)
        {
            // TODO add file header
            string target_filepath = Path.Combine(Config.spixiUserFolder, Config.walletFile);
            WalletStorage ws = new WalletStorage(source_path);
            if (!ws.verifyWallet(source_path, pass))
            {
                Utils.sendUiCommand(this, "showPasswordError");
                // Remove overlay
                Utils.sendUiCommand(this, "removeLoadingOverlay");
                return false;
            }
            else
            {
                File.Move(source_path, target_filepath);
                Node.loadWallet();
            }
            Navigation.PushAsync(HomePage.Instance(true), Config.defaultXamarinAnimations);
            removePage(this);
            return true;
        }

        protected override bool OnBackButtonPressed()
        {
            popPageAsync();

            return true;
        }
    }
}