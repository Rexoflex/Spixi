/* Blockchain-scan progress (#440 / #443, Damir).
 *
 * WHAT THIS ACTUALLY REPORTS — and why the copy matters. Spixi's TIV runs in
 * `Minimal` mode: it walks block HEADERS against a cuckoo filter of the user's OWN
 * addresses, looking for transactions that involve them. It is NOT downloading a
 * chain. Calling it "syncing the blockchain" oversells it and invites exactly the
 * question we do not want ("why is my phone downloading a blockchain"), so every
 * string here talks about looking for the user's transactions.
 *
 * ★ ZERO MEANS UNKNOWN, NOT 0%. `getLastBlockHeight()` is 0 before the first header
 * lands and `determineHighestNetworkBlockNum()` is 0 with no peers — dividing them
 * gives a confident, wrong 0%. The INDETERMINATE state exists for that moment and
 * pairs with the N19 connecting line, which is the same "we do not know yet".
 *
 * ★ THE ORIGIN IS THE SESSION START, not the baked checkpoint. A resumed run
 * continues from stored headers nowhere near CoreConfig.bakedBlockHeight, so
 * anchoring there would make every launch read a few percent while the client is
 * current. C# captures the first height it sees and passes it in.
 *
 * It STEPS rather than glides: TIV pulls headers 250 at a time
 * (blockHeadersToRequestInChunk). That is honest — the width transition is short on
 * purpose so the bar does not pretend to a smoothness the data does not have.
 *
 * createScanProgress({ strings }) → section  (hidden until setScanProgress says
 *                                             otherwise)
 * setScanProgress(el, { current, target, origin, strings }) → el
 *   current/target/origin are block numbers (Number or numeric string).
 *   Hidden when the scan is current — a bar resting at 100% is noise.
 */
import { getStrings } from './strings-runtime.js';
import { icon } from './icons.js';

/** Parse a bridge number arg: '' / null / NaN → 0 (= unknown). */
function num(v) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
}

export function createScanProgress({ strings = getStrings() } = {}) {
  const el = document.createElement('section');
  el.className = 'c-scanprog';
  el.hidden = true;
  /* ★ Audit MINOR-7: the live region is on the TITLE, not on the whole strip. C#
     pushes at 1 Hz, so a section-level live region re-announced the percentage, the
     heading and the explanation together once a second for the whole catch-up. The
     title only changes on a STATE change, which is the thing worth announcing. */

  const head = document.createElement('div');
  head.className = 'c-scanprog__head';

  const glyph = document.createElement('span');
  glyph.className = 'c-scanprog__glyph';
  glyph.setAttribute('aria-hidden', 'true');
  glyph.append(icon('search', { size: 16 }));

  const title = document.createElement('span');
  title.className = 'c-scanprog__title';
  title.setAttribute('aria-live', 'polite');
  title.textContent = strings.chainScanTitle || 'Looking for your transactions';

  const pct = document.createElement('span');
  pct.className = 'c-scanprog__pct u-tabular';

  head.append(glyph, title, pct);

  const track = document.createElement('div');
  track.className = 'c-scanprog__track';
  track.setAttribute('role', 'progressbar');
  track.setAttribute('aria-valuemin', '0');
  track.setAttribute('aria-valuemax', '100');
  track.setAttribute('aria-label', strings.chainScanTitle || 'Looking for your transactions');   // audit MINOR-7: a progressbar needs a name
  const fill = document.createElement('span');
  fill.className = 'c-scanprog__fill';
  track.append(fill);

  const note = document.createElement('p');
  note.className = 'c-scanprog__note';
  note.textContent = strings.chainScanNote
    || 'Spixi is checking recent blocks for transactions that involve your address.';

  el.append(head, track, note);
  el._parts = { title, pct, track, fill, note };
  return el;
}

export function setScanProgress(el, { current, target, origin, strings = getStrings() } = {}) {
  if (!el || !el._parts) return el;
  const { title, pct, track, fill, note } = el._parts;

  const cur = num(current);
  const tgt = num(target);
  const org = num(origin);

  /* ★ AUDIT MAJOR-2 — WHEN IS A CLIENT "CAUGHT UP".
   *
   * The first cut hid only on `cur >= tgt`, and that is not what a synced client
   * looks like. `getHighestKnownNetworkBlockHeight()` is max(ourHeight, a peer
   * majority) and the majority estimate is itself extrapolated from the last block's
   * timestamp — so a fully synced phone reads `target = current + 1` for the window
   * between "a block is due" and "TIV fetched it", roughly once every 30 seconds.
   * With no threshold the strip popped in at 98%, vanished, and popped back, inserting
   * and removing a block of layout above the transaction list each time. At boot the
   * same client hit `origin == current` and rendered a confident "0%" — precisely the
   * reading this component exists to prevent.
   *
   * So: a LAG THRESHOLD decides whether there is anything to report, and it is
   * HYSTERETIC — a wide band to appear, a narrow one to disappear — so the strip
   * cannot flap at its own boundary. SHOW_LAG is ~10 minutes of chain at the 30s
   * block interval; anything inside that is not something a user would call
   * "catching up". */
  const SHOW_LAG = 20;   // blocks behind before we say anything at all
  const HIDE_LAG = 2;    // blocks behind before we stop saying it (hysteresis band)
  /* ★ break-my-verdict MAJOR-1: this must be "was I already reporting a SCAN", not "am
   * I visible". The UNKNOWN state un-hides, and C# guarantees an unknown (0,0,0) frame
   * on every boot (its change-detector starts at ulong.MaxValue and getLastBlockHeight()
   * is 0 before the first header lands). Keyed on el.hidden, the FIRST real frame was
   * therefore judged against HIDE_LAG instead of SHOW_LAG — so a caught-up phone 3 to 20
   * blocks behind rendered "0%" on every launch, which is the exact reading the whole
   * threshold exists to prevent. */
  const showing = el.dataset.state === 'scanning';
  if (cur > 0 && tgt > 0) {
    const lag = tgt - cur;
    if (lag <= (showing ? HIDE_LAG : SHOW_LAG)) {
      el.hidden = true;
      delete el.dataset.state;
      return el;
    }
  }

  // ★ UNKNOWN. Either end at zero means "we have not been told yet" — never 0%.
  if (cur === 0 || tgt === 0) {
    el.hidden = false;
    el.dataset.state = 'unknown';
    title.textContent = strings.chainScanTitle || 'Looking for your transactions';
    pct.textContent = '';
    track.removeAttribute('aria-valuenow');
    fill.style.width = '';
    note.textContent = strings.chainScanNoteUnknown
      || 'Spixi is connecting, then it will check for transactions that involve your address.';
    return el;
  }

  // Origin below the current height is the session anchor; anything else (a stale or
  // missing origin, an origin above the current height after a re-org) falls back to
  // the current height, which yields 0% rather than a negative or >100% reading.
  const base = (org > 0 && org < cur) ? org : cur;
  const span = tgt - base;
  const done = cur - base;
  const p = span > 0 ? Math.max(0, Math.min(99, Math.round((done / span) * 100))) : 0;

  el.hidden = false;
  el.dataset.state = 'scanning';
  title.textContent = strings.chainScanTitle || 'Looking for your transactions';
  pct.textContent = p + '%';
  track.setAttribute('aria-valuenow', String(p));
  fill.style.width = p + '%';
  note.textContent = strings.chainScanNote
    || 'Spixi is checking recent blocks for transactions that involve your address.';
  return el;
}
