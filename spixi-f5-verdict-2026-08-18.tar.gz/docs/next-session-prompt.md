Read docs/handoff-2026-08-19e.md FIRST and verify the git state it describes (the
#391-#394 launch-flow batch, committed, on top of 33604365 - if the chain does not
match, stop and say so). Confirm Spixi/Meta/Config.cs reads "spixi-0.9.22". This
session runs in #380 BUDGET MODE - the scope is PINNED, do not widen it.

THREE BODIES OF WORK, in this order. Do the fixes FIRST - they are small, two of
them are already root-caused, and the rest touches the same screens.

PART A - THE #391 F5 FIX LIST (DECISIONS #395). TRIAGE-FIRST (#215) still applies:
where I have named a mechanism, verify it at source before you touch anything;
where I have NOT, get evidence before you code.

F-1 backup nudge fires on an UNACCEPTED contact - ROOT CAUSE FOUND, just fix it.
Friend.approved DEFAULTS TO TRUE (Ixian-Core Streaming/Friends/Friend.cs:196, ctor
:233) and every outgoing request in this app adds the friend without passing it
(HomePage.joinBot:1378, ContactNewPage:195, SingleChatPage:1426,
SpixiContentPage:2389). So my #393 MAJOR-3 guard is dead code. Use
friend.state == FriendState.Approved (the predicate #275 already uses), keep
!pendingDeletion, !bot and the balance leg, and re-pin the smoke on the STATE.

F-2 hardware back exits the app from the create/restore view. The view switch and
the topbar Back both work, so C#'s currentView is wrong. DO NOT GUESS: add one log
line in LaunchPage.onNavigating naming every verb it receives (the N65
instrumentation precedent), so one F5 says whether ixian:create arrives. Then make
it structural - the component must report EVERY view change from ONE place, inside
show() in launch-shell.js, instead of only from the two CTA hooks.

F-3 restore = fatal exception, then no network, empty chats and contacts. DEFERRED
BY DAMIR - DO NOT FIX IT THIS SESSION. It rides the delete-account / delete-wallet
line of work, because those paths share the same wallet lifecycle and he wants them
done together, once. The suspect list is recorded in handoff section 2 (F-3) - do
not re-derive it, and do not "just look" at it.

F-4 the status bar stays dark after unlocking - ROOT CAUSE FOUND. #393 MAJOR-4 put
repaintSystemBars in closeOverlay, but the resume lock closes through
closeModalOverlay (SpixiContentPage.cs:647, called from LockPage.performUnlock:165
and :119), and the non-confirm path ends in InsertPageBefore + removePage
(LockPage.xaml.cs:177) with no navigation at all. Repaint at both lock-close sites.
ALSO FIX THE PIN - it counted two call sites of the right function in the wrong
method and passed. Pin the site the behaviour runs through.

F-5 empty states pop in about a second late on every screen after a restart.
Triage before building. Prime suspect is the deliberate zero-state load-window gate
(chats-shell.js:164, zeroReady === false returns null), possibly just newly visible
because we now test empty accounts. Ask whether the gate opens late or the burst
arrives late. Remember #387: check the reporting build was clean.

PART B - THE FULL-BLEED ROUND (AND-7, DECISIONS #396). This is what Damir actually
asked for three times: not a strip that MATCHES the screen, but no strip at all.
It is already triaged and unblocked in docs/android-findings.md:47 - MainActivity's
InsetsListener pads the root view top by sysInsets.Top while
SetDecorFitsSystemWindows(false) already draws edge-to-edge, so the fix is to stop
padding the top and feed the real top inset to the shells as a CSS variable
(Android env(safe-area-inset-top) is cutout-only, which is why the iOS #282 chrome
reads 0 there). Scope: the LAUNCH gradient, the WALLET HERO where the balance sits
(his named ask), and every shell topbar. MEASURE FIRST (#294): print the real
sysInsets.Top and what env() reports inside the WebView on his device, before you
change the listener. The #391 strip colours STAY as the pre-paint frame - they just
stop being the mechanism.

PART C - ITEM 6 IS DECIDED, BUILD IT (small, do it with Part A). The join-community
CTA stays in the chat-list empty state AND gets a permanent row in How to use, so a
user who adds any ordinary contact does not lose the door. No dismissible chat row.
★ Verified shape, do not rediscover it: createSettingsHowTo is
src/components/settings-app.js:553, rendered by src/shells/settings.html:1039,
whose host is SettingsPage - and SettingsPage does NOT handle ixian:joinBot (zero
hits; only HomePage does, :788 -> private joinBot() :1376-1391). So add the action
row and make the join a SHARED STATIC both pages call - the
BackupPage.backupAccount() precedent (#243). Do not invent a second verb and do not
duplicate the addFriend call. It stays opt-in: nothing is added until it is tapped.

NOT THIS SESSION: N71 (the theme push-vs-reload round - its own batch) - N57
(Core-side, his protocol run) - N63 - N64 - N67 - N68 - N69 - N70 - the deferred
pile. F-3 (the restore crash) is DEFERRED to the delete-account/delete-wallet
batch - Damir's call. Group chat is ANSWERED (handoff section 6): inherited from Ixian-Core,
predates our fork, the creator is a permanent relay. No work owed unless he asks
for a BE row.

ECONOMY RULES (hard): smoke as bookends only - baseline once (expect 1992/4) and
final once (state the new number) - plus ONE batched mutation-proof run for any new
pins. ONE Opus review round at the end, and only if C#/money/data paths changed; no
r2/r3 unless it finds a MAJOR. No agent fan-outs. Standing set otherwise unchanged:
cloud twin - verify against code (#215) - bundle BEFORE shells, and READ the bundle
build's output (#383) - build-shells writes 18 shells now, one launch output - locale
pipeline + i18n-lint + pseudo + i18n-overflow-audit IF strings changed - DECISIONS
rows at decision time - security gate row - tarball delivery + updated handoff + F5
checklist (short - only the legs the session touched). Any C# change means I wipe
obj/bin before deploying, and both targets share those folders. I commit.

★ AND REMEMBER #395: a smoke pin can PASS and still prove nothing. F-4 shipped
because the pin asserted the fix EXISTED rather than that it ran on the path the
bug takes. When you pin a fix, pin the site the behaviour goes through.
