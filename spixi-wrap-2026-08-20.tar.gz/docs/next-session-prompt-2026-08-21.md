Read `docs/handoff-2026-08-20.md` FIRST, then `docs/f5-verdict-2026-08-20.md`, then
DECISIONS.md rows **#436–#453**. The batch is BUILT, DEPLOYED TO ANDROID AND F5'd — the
verdict file is the device truth, not a plan.
Smoke baseline is **2219 pass / the 4 known pre-existers** (#136 · #149③ · M5 · B3).
Shells: 18. Everything is UNCOMMITTED.

★ **THIS SESSION IS NO-BE WORK ONLY.** Anything that needs the BE engineer is out of
scope — including reply-to, whose Ixian-Core carrier is deliberately held out in
`docs/be-cutover-ixian-core-reply-carrier.md`. **Ixian-Core stays at `097341a`**, and five
smoke pins (the hold-out gate) fail if an edit sneaks back in. Do not "helpfully" land it.

SETUP — both repos clone anonymously:
git clone --branch redesign/frontend https://github.com/Rexoflex/Spixi.git
git clone https://github.com/ixian-platform/Ixian-Core.git   # SIBLING folder, REQUIRED to build
npm install jsdom --no-save
Verify before building: `Config.cs` reads `spixi-0.9.22`, smoke green at **2219 / the same
4**, Ixian-Core clean. If not, say so and stop.

---

# THE WORK, in priority order

## 1 — ★ THE LOCK STILL EXPOSES THE SCREEN (#442 / §C). The headline, and it FAILED.

**Read #438, #442 and §C of the verdict before touching anything.** The shield I built
does not work, and the diagnosis is solid:

**The cover is added at `OnSleep`, but Android is backgrounding the app by then and will
not paint another frame.** So it exists in the view tree and is NEVER DRAWN. The last real
frame stays — which is both what the task-switcher snapshot captures and what gets
restored on resume. ⚠ **Tuning the resume path cannot fix this**, because the content is
on screen before any managed code runs. Damir sees it on every resume shape: chats, a
conversation, wallet, account, a sheet, a call.

**The two mechanisms that can work, and they are complementary:**

* **`FLAG_SECURE` on the activity window while the lock is enabled.** This is what makes
  Android blank the recents thumbnail. It is the only thing that fixes C2.1. ⚠ It also
  blocks screenshots for the user — **that is a product decision and it is Damir's**, so
  ask before shipping it and offer the trade-off plainly.
* **★ Present the lock at PAUSE, not at RESUME.** If the lock is already on screen when
  the app goes to the background, the last drawn frame IS the lock, the snapshot is the
  lock, and there is nothing to flash on the way back. This is what Signal and WhatsApp
  do. ⚠ It interacts with the 5-second cooldown: you would present on pause and dismiss
  WITHOUT auth on a resume inside the window. **Get Damir's call on that before building**
  — it changes when the app is protected, which is a security posture question, not a
  layout one.

⚠ Do NOT revert to a plain modal push — that re-opens the flicker #229 removed (#423).
⚠ Whatever you build, C3.1 must stay clean: with the lock OFF there must be **no dark
flash at all**. Damir reported flicker there too, so check the disable-the-lock path — it
presents a LockPage to authorise turning the lock off, and that present has its own flash.
⚠ C4.1: cold start flashes the password screen before the OS prompt takes over. Smaller,
different, worth a look while you are in there.

## 2 — 🔴 G5, SHARE REGRESSED, and I have NO working theory

Tapping the rightmost icon in the Account address row copies to the clipboard instead of
opening the OS share sheet. **Damir confirms it worked before this batch.**

What is already ruled out, so do not re-derive it: my diff on that path is provably
additive; the hit-area geometry means the share button's centre can never fall inside the
ⓘ's hit area; and the row does not overflow, because the address has `min-width: 0` and
`break-all`. I twice asserted things about this that were wrong — **do not guess a third
time, instrument it.** `shareAddress` in `settings.html` falls back to
`copyAddressFallback` on any throw or rejection, and swallows the reason. Log the actual
error first — dev mode is 10 taps on the "Chats" title, and DevPage renders the log.

## 3 — 🔴 #449, the tx header shows a FULL address

Damir sees it on a CLEAN build, so the stale-package theory is dead. ⚠ I could not
reproduce it at source: `home.html:2976` truncates for the sheet, `wallet_sent.html:273`
truncates for the page — and that second one was added by **#276 for this exact
complaint**. Driven in jsdom with his own address, the list row rendered correctly
truncated. So something about the real push differs from what I fed it. Get the actual
pushed `username` value out of the app before changing either regex.

## 4 — A fresh wallet should show the EMPTY STATE, not "Checking for your transactions"

Damir's call. With a brand-new wallet there is nothing to look for, so the scan row is
noise. Decide the condition honestly: "no transactions AND the scan has never had a
reason to run" is not the same as "the scan is at 0%".

## 5 — Re-test what was fixed after the verdict, then the remaining V1.1 rows

`docs/f5-verdict-2026-08-20.md` lists eight fixes landed after Damir's sweep that he has
NOT re-tested — the scan anchor twice over, the row margins, the two-line tx header, the
Status move, the Close button, the wallet zero-state art, the address ⓘ. Re-run §B, §D and
§G of `docs/f5-scenarios-2026-08-20.md` against the new build first; do not assume.

Then the standing no-BE rows in `docs/master-worklist-2026-08-17.md`.

---

# DO-NOTs

1. **Do not touch Ixian-Core.** Held for the BE cutover. The hold-out gate enforces it.
2. **Do not declare the `reply` capability.** With no carrier it renders a Reply action
   that silently drops the quote — worse than no feature.
3. **Do not re-open the R3 art** (#433) or **N31** (deferred) or **N61** (a feature, #439a).
4. **Do not build group rename / photo / add-members** — verified NOT in Ixian-Core. BE.
5. **Do not fix the lock by reverting to a plain modal push** (#423).

# STANDING RULES THIS PROJECT KEEPS RE-EARNING

* **★ A pin that passes vacuously is worse than none — it happened THREE times last
  batch.** A regex blessed a guard that killed the feature it pinned; a gate matched a line
  that appears three times in one file; and two negative assertions matched the very
  docblocks explaining what they forbid. **Match on the CALL, strip comments for negative
  tests, and slice to the FUNCTION rather than to a byte budget** — a comment added inside
  a function pushed `compact: true` past an `indexOf + 1400` window and turned a pin red
  with the behaviour untouched.
* **★ MUTATE BEFORE BELIEVING.** All three of the above were caught by mutating, none by
  reading.
* **★ A TEST SHEET IN THE WRONG SHELL IS WORSE THAN NO SHEET.** Damir runs **PowerShell**.
  `rmdir /s /q` is CMD and silently does nothing. A quoted path at the start of a line
  needs the call operator `&`. **NO UNQUOTED PARENTHESES in a pasted block.**
* **★ SOURCE-READING GATES CANNOT SEE A THROW, A CASCADE, OR ARITHMETIC.** Two scan-strip
  MAJORs last batch were percentages, and only running the component found them.
* **★ A REPAIR REGRESSES A PASSED ROUND MORE OFTEN THAN IT FAILS ON ITS OWN** (#423). Three
  of six MAJORs last batch were in the FIXES. Run the break-my-verdict pass over repairs.
* **★ VERIFY THE RIGHT QUESTION** (#215). "Does our tree handle both message codes" was
  answered yes; "does a DEPLOYED peer handle both" was the question that mattered.
* **★ TRANSLATIONS ARE PART OF THE BUILD.** Every new and CHANGED string gets a real value
  in all 13 locales. `build-locales` emits drafts; a draft is not a translation.
* Verify at source · never build past a missing repro (#294) · **bundle BEFORE shells** ·
  DECISIONS rows at decision time · smoke as bookends · `git --no-optional-locks` always ·
  **#387 wipe `obj`/`bin` on any C# change**.

# DELIVERY — how Damir works

* Windows, **PowerShell**, at his machine, with an Android device on adb.
* Land everything on his disk and leave it **UNCOMMITTED**, with a full green pipeline:
  extract-strings → build-locales → build-strings-iife → build-demo-bundle → build-shells →
  i18n-lint → pseudo-locale-smoke → smoke.
* **Give him ONE step at a time and WAIT.** Never stack a command and a prerequisite.
* Expectations in a table OUTSIDE the pasted block, and tell him what NUMBER to expect from
  each step — a stale build and a real bug look identical without the discriminator.
* ⚠ **Check the device is on adb BEFORE the run step.** `-t:Run` only looks at the end of a
  build, so a missing phone costs the whole build first (#450).
* Deploy — Android: `dotnet build Spixi\Spixi.csproj -f net10.0-android -c Release`, then
  `-t:Run` as a SECOND command (a wipe makes `-t:Run` fail alone, #320).

# STILL UNVERIFIED

iOS and Windows, for six batches. The Android in-call strip has never been exercised — it
needs a real two-device call.
