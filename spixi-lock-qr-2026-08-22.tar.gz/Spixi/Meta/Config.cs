﻿using IXICore.Meta;
using IXICore.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace SPIXI.Meta
{
    public class Config
    {
        // Providing pre-defined values
        // Can be read from a file later, or read from the command line

        public static NetworkType networkType = NetworkType.main;

        public static bool enablePushNotifications = true;

        public static string walletFile = "wallet.ixi";

        public static string spixiUserFolder = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "Spixi");

        public static string activityFolderPath = "";
        public static string headersFolderPath = "";
        public static string logFolderPath = "";

        public static int encryptionRetryPasswordAttempts = 3;   // How many allowed attempts in the LaunchRetry page before throwing the user back to Launch Page

        // Read-only values
        public static readonly string aboutUrl = "https://www.spixi.io";
        public static readonly string guideUrl = "https://www.spixi.io/help-center.html";
        public static readonly string explorerUrl = "https://explorer.ixian.io/";
        public static readonly string spixiAppsUrl = "https://apps.spixi.io/";

        public static readonly string pushServiceUrl = "https://ipn.ixian.io/v2";
        public static readonly string priceServiceUrl = "https://resources.ixian.io/ixiprice.txt";

        public static readonly int checkPriceSeconds = 1800; // 30 minutes

        public static readonly int packetDataSize = 102400; // 100 Kb per packet for file transfers
        public static readonly long packetRequestTimeout = 60; // Time in seconds to re-request packets

        public static readonly string version = "spixi-0.9.22"; // Spixi version

        public static readonly string checkVersionUrl = "https://resources.ixian.io/spixi-update.txt";
        public static readonly int checkVersionSeconds = 1 * 60 * 60; // 1 hour

        public static readonly string supportEmailUrl = "mailto:support@spixi.io?subject=Spixi%20Feedback&body=Please%20tell%20us%20why%20Spixi%20didn't%20meet%20your%20expectations%20or%20describe%20any%20problems%20you%20experienced.%0A%0AWhat%20did%20you%20like%3F%0AWhat%20didn't%20you%20like%3F%0ADid%20you%20encounter%20any%20bugs%20or%20issues%3F%0AWhat%20could%20we%20do%20better%3F%0A%0AThank%20you%20for%20helping%20us%20improve%20Spixi.";
        public static readonly string ratingAndroidUrl = "https://play.google.com/store/apps/details?id=com.ixilabs.spixi&reviewId=0";
        public static readonly string ratingiOSUrl = "https://apps.apple.com/app/id6667121792?action=write-review";



        // Default SPIXI settings
        public static bool defaultXamarinAnimations = false;
        public static uint messagesToLoad = 50;  // N52: 25 → 50 (the #343 cut overshot — 25 rows rarely cover one screen of history). Was 100 pre-#343. ⚠ every row is its own EvaluateJavaScriptAsync marshal (#298) — re-measure chat entry on the A52 (the #349 baseline is 234 ms cold at 25).
                                                 // Opening a chat pushes ONE EvaluateJavaScriptAsync per message
                                                 // (Utils.sendUiCommand:180 -> SpixiContentPage:187), and the shell
                                                 // then waits 250 ms after the LAST one before its single render.
                                                 // 100 messages therefore meant ~100 process-boundary crossings
                                                 // before anything appeared - the measured cause of "entering a chat
                                                 // is laggy". 25 fills a phone screen with room to spare; load-more
                                                 // fetches the next chunk with the same constant. Revert this line
                                                 // alone to undo. The real fix is batching the push (be-cutover, the
                                                 // addMessages verb in docs/chat-transport-spec.md).
        public static ulong txConfirmationBlocks = 10; // Number of blocks until transaction is confirmed

        // Push notifications OneSignal AppID
        public static string oneSignalAppId = "af20710d-7d68-4038-94a4-2896f3029263";

        // VoIP settings, don't change
        public static readonly int VoIP_sampleRate = 16000;
        public static readonly int VoIP_bitsPerSample = 16;
        public static readonly int VoIP_channels = 1;
        public static readonly long backupReminder = 86400 * 30; // 1 month

        public static int maxRelaySectorNodesToConnectTo = 3;


        public static int maxLogSize = 5;
        /* ★ RELEASE BLOCKER — REDUCE TO 1 BEFORE LAUNCH (Damir, 2026-08-22: "yes raise it
         * for now. but remember to reduce before we launch").
         *
         * Logging.start calls roll(true) on EVERY launch (Ixian-Core Logging.cs:116), so at
         * a count of 1 the app keeps exactly ONE previous session. That destroyed the
         * evidence for #505 — the Windows black-window session was overwritten by the very
         * restart the user performed to recover from it, which is the ONE action the defect
         * guarantees. 5 keeps roughly a working day of sessions and costs at most 25 MB at
         * maxLogSize = 5.
         *
         * ⚠ A smoke pin asserts this value and names this row, so the reduction cannot be
         * forgotten silently — change both together. */
        public static int maxLogCount = 5;

        public static int logVerbosity = (int)LogSeverity.info + (int)LogSeverity.warn + (int)LogSeverity.error;

        // Store the device id in a cache for reuse in later instances
        public static string externalIp = "";

        public static string configFilename = "ixian.cfg";

        public static byte[]? checksumLock = null;

        public static int maxConnectedStreamingNodes = 6;

        public static Dictionary<string, string> apiUsers = new Dictionary<string, string>();

        public static List<string> apiAllowedIps = new List<string>();
        public static List<string> apiBinds = new List<string>();

        public static ulong activityDbCacheSize = 8 << 20; // 8MB
        public static ulong blocksDbCacheSize = 8 << 20;

        public static long minRequiredDiskSpace = 50 << 20; // 50MB


        private static NetworkType parseNetworkTypeValue(string value)
        {
            NetworkType netType;
            value = value.ToLower();
            switch (value)
            {
                case "mainnet":
                    netType = NetworkType.main;
                    break;
                case "testnet":
                    netType = NetworkType.test;
                    break;
                case "regtest":
                    netType = NetworkType.reg;
                    break;
                default:
                    throw new Exception(string.Format("Unknown network type '{0}'. Possible values are 'mainnet', 'testnet', 'regtest'", value));
            }
            return netType;
        }

        private static void readConfigFile(string filename)
        {
            if (!File.Exists(filename))
            {
                return;
            }
            Logging.info("Reading config file: " + filename);
            bool foundAddPeer = false;
            bool foundAddTestPeer = false;
            List<string> lines = File.ReadAllLines(filename).ToList();
            foreach (string line in lines)
            {
                string[] option = line.Split('=');
                if (option.Length < 2)
                {
                    continue;
                }
                string key = option[0].Trim([' ', '\t', '\r', '\n']);
                string value = option[1].Trim([' ', '\t', '\r', '\n']);

                if (key.StartsWith(";"))
                {
                    continue;
                }
                Logging.info("Processing config parameter '" + key + "' = '" + value + "'");
                switch (key)
                {
                    case "apiAllowIp":
                        apiAllowedIps.Add(value);
                        break;
                    case "apiBind":
                        apiBinds.Add(value);
                        break;
                    case "addApiUser":
                        string[] credential = value.Split(':');
                        if (credential.Length == 2)
                        {
                            apiUsers.Add(credential[0], credential[1]);
                        }
                        break;
                    case "externalIp":
                        externalIp = value;
                        break;
                    case "addPeer":
                        if (!foundAddPeer)
                        {
                            NetworkUtils.seedNodes.Clear();
                        }
                        foundAddPeer = true;
                        NetworkUtils.seedNodes.Add([value, null]);
                        break;
                    case "addTestnetPeer":
                        if (!foundAddTestPeer)
                        {
                            NetworkUtils.seedTestNetNodes.Clear();
                        }
                        foundAddTestPeer = true;
                        NetworkUtils.seedTestNetNodes.Add([value, null]);
                        break;
                    case "maxLogSize":
                        maxLogSize = int.Parse(value);
                        break;
                    case "maxLogCount":
                        maxLogCount = int.Parse(value);
                        break;
                    case "logVerbosity":
                        logVerbosity = int.Parse(value);
                        break;
                    case "checksumLock":
                        checksumLock = Encoding.UTF8.GetBytes(value);
                        break;
                    case "networkType":
                        networkType = parseNetworkTypeValue(value);
                        break;
                    case "logFolderPath":
                        logFolderPath = value;
                        break;
                    case "activityFolderPath":
                        activityFolderPath = value;
                        break;
                    case "headersFolderPath":
                        headersFolderPath = value;
                        break;
                    case "dataFolderPath":
                        spixiUserFolder = value;
                        break;
                    case "wallet":
                        walletFile = value;
                        break;
                    case "blocksDbCache":
                        blocksDbCacheSize = ulong.Parse(value);
                        break;
                    case "activityDbCache":
                        activityDbCacheSize = ulong.Parse(value);
                        break;
                    case "spixiUserFolder":
                        spixiUserFolder = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), value);
                        break;
                    default:
                        // unknown key
                        Logging.warn("Unknown config parameter was specified '" + key + "'");
                        break;
                }
            }
        }

        public static void init()
        {
            readConfigFile(configFilename);

            if (headersFolderPath == "")
            {
                if (networkType == NetworkType.main)
                {
                    headersFolderPath = Path.Combine(spixiUserFolder, "headers");
                }
                else
                {
                    headersFolderPath = Path.Combine(spixiUserFolder, "testnet-headers");
                }
            }

            if (activityFolderPath == "")
            {
                if (networkType == NetworkType.main)
                {
                    activityFolderPath = Path.Combine(spixiUserFolder, "activity");
                }
                else
                {
                    activityFolderPath = Path.Combine(spixiUserFolder, "testnet-activity");
                }
            }

            if (logFolderPath == "")
            {
                logFolderPath = spixiUserFolder;
            }
        }
    }
}