# F5 checklist — Session P (the pre-warm #800 + the batch transport #801 + the loop #802)

Both levers are ONE build. The stamps stay separable: `attach spare=` says which path an
open took, `batch n= json= t=` and the shell's `batch=` token say which transport carried it.

---

## §1 · The gates (run each block on its own — ONE command per block)

```powershell
cd "C:\Users\Damir\Claude\Projects\Spixi Rework Of Frontend\Spixi"
```

```powershell
node scripts/extract-strings.mjs --check
```

```powershell
node scripts/build-demo-bundle.mjs
```

```powershell
node scripts/build-shells.mjs
```

```powershell
node scripts/build-shells.mjs --check
```

```powershell
node scripts/build-legal-docs.mjs --check
```

```powershell
node scripts/i18n-lint.mjs
```

```powershell
node scripts/pseudo-locale-smoke.mjs
```

```powershell
node scripts/verify-locales.mjs
```

```powershell
node scripts/cs-syntax-check.mjs
```

```powershell
node scripts/smoke-test.mjs
```

Expected, exactly: bundle **320 exports** · **18 shells** · `build-shells --check` ✓ ·
`extract-strings --check` ✓ · `build-legal-docs --check` ✓ · i18n-lint ✓ (6 dev exemptions) ·
pseudo **9/9** · locales **784 ALL CLEAN** · cs-syntax **138 + 1** ·
smoke **BASELINE OK 4360 / the 3 known (#136 · M5 · B3)**.

> The 4360 assumes the **Ixian-Core sibling is present** beside the repo. Without it the
> number is 4359 (the M1 `#448` pair). Record which you ran.

---

## §2 · Build

C# changed in five files, so the incremental build is not enough.

```powershell
Remove-Item -Recurse -Force .\Spixi\obj, .\Spixi\bin -ErrorAction SilentlyContinue
```

Then **F5 in Visual Studio** for Windows — `dotnet build` does NOT stage `MauiAsset` beside
`Spixi.exe` and the app then silently serves the previous build's shell (#663). Android is
unaffected; deploy it the usual way.

---

## §3 · THE MEASUREMENT — the only thing that says whether the levers worked

This is the point of the session. Do it before the feature walk; the numbers are worth more
than any of the P/F rows below.

### 3a · BEFORE — on the Session O build (the one already on the phone)

Release + `SPIXI_DEV_COEXIST`, logcat mirrored (#751). Two captures:

1. **Eight chat opens** — different conversations, from a cold-ish list each time. Paste every
   `[CDPERF] chat …` line. (This is the #796 capture again; if you still have it, reuse it.)
2. **Eight chats-after-close lines** — open a conversation, close it, wait two seconds, repeat.
   Paste every `[CDPERF] chats-after-close frames n= drop= max=` line. That probe is #799's
   BEFORE instrument and it sits on the exact line where the pre-warm now schedules.

### 3b · AFTER — on THIS build

3. **Eleven chat opens.** Expect **8 with `attach spare=1 tap=…ms`** and **3 with
   `attach spare=0 why=<word>`** — the three refusals are normal (a tap inside the 350 ms
   window, a tap while a lock or a pane is staging). Paste all eleven lines.
4. **The same eight chats-after-close lines.** ⚠ **This is the acceptance test for the warm.**
   `drop=` and `max=` must not RISE against 3a. If they do, the warm is being paid for by the
   chats list, and the fix is to delay it or gate it on list idle — not to keep it.
5. **Memory at rest.** After ten minutes idle on the chats list with a spare warm, the
   `meminfo` split (#764's instrument, Mac + cable). One hidden WebView is the cost of the
   lever; we should know what it is.

### How to read the lines

| line | means |
|---|---|
| `chat warm start` | a spare is loading |
| `chat warm onload t=<ms>` | its shell booted — this is the cost paid OFF the critical path |
| `chat warm refused why=<word>` | no spare was made. `background` while backgrounded is normal and re-arms |
| `chat warm drop why=<word>` | a spare was thrown away (a theme flip, a language pick, sleep, a refused tap) |
| `chat attach spare=1 tap=<ms>` | the open rode the spare. **`tap=` is tap → attach** |
| `chat attach spare=0 why=<word>` | the open took today's path, and `why` says which guard refused |
| `chat batch n=<rows> json=<chars> t=<ms>` | the whole history crossed once. `t=` is the BUILD, and it over-measures on purpose (§3c) |
| `chat-shell … batch=1` | the shell rendered from the batch. `batch=0` means the old per-row path |

⚠ **An attach that THROWS leaves TWO lines for ONE open** — `spare=1 tap=…` then
`spare=0 why=attach`. Read the pair as one refused open, not two.

### 3c · `t=` on the batch line

`t=` starts before the message lock, so it also covers the lock wait and one metadata save.
It **over-measures**, which is the safe direction: it bounds the window in which the shell's
500 ms first-paint fallback could still fire. If `t=` is comfortably under 500 ms on your
largest conversation, that race is closed and nobody needs to dial the timeout. If it is not,
say so and we measure the fallback rather than guessing at it (#294).

---

## §4 · The walk

Open `docs/walk-artifact-session-p.html` in a browser — P / F / N per row, one copyable block
at the end. The rows below are the same list, for the record.

### The pre-warm

| # | row | expect |
|---|---|---|
| A1 | Open a conversation from the chats list, twice in a row | Both open. The second is the interesting one: it should feel immediate |
| A2 | Close a chat, wait a second, open ANOTHER one | `spare=1`. This is trigger A |
| A3 | Cold start → wait on the chats list → open a chat | `spare=1`. This is trigger B |
| A4 | Open a chat within ~300 ms of closing one (fast tapping) | `spare=0 why=warming` and the chat still opens normally |
| A5 | Flip the OS theme, then open a chat | The conversation is in the NEW theme. `warm drop why=theme` in the log |
| A6 | Account → Language → pick another → open a chat | The conversation is in the new language |
| A7 | **Account → Chat appearance → change the TEXT SIZE → back → open a chat** | The new size, on the FIRST open. This was a real defect (r2) |
| A8 | Same, but change the pattern or the ground | Same answer |
| A9 | Background the app for a minute, return, open a chat | Opens normally. On mobile the spare was dropped on sleep |
| A10 | Desktop: narrow the window, wait, widen it, open a chat | Opens in the right column, no resize flash |
| A11 | Desktop: lock the app (or wait for the idle lock), unlock, open a chat | Opens normally |
| A12 | Open a chat, then open a SECOND one straight from the first | Both open. No conversation is ever invisible |

### The batch transport

| # | row | expect |
|---|---|---|
| B1 | Open a conversation with a long history | It paints ONCE. No fill-in, no flicker. `batch n=` says how many rows crossed |
| B2 | Open a conversation with exactly ONE message | The message is there. (A one-token slip opened these EMPTY — r10) |
| B3 | Open a conversation with NO messages | The secure notice, no spinner left behind |
| B4 | **Open a conversation whose first row is a contact request** | The whole history is there (r11 — this one opened empty) |
| B5 | Scroll up → "Show older messages" | The older slice lands and **your reading position holds** — no jump to the bottom |
| B6 | A conversation with reactions | Every pill is on the right message |
| B7 | A GROUP with reactions and unread messages | Same, and the unread divider is where you left off |
| B8 | Delete every message in a chat | It empties immediately |
| B9 | A bot: switch channels | The channel's history paints once |
| B10 | Receive a message WHILE a chat is opening | It appears. It is not swallowed by the load (r5) |
| B11 | A conversation with avatars on many rows | Avatars render; `json=` is not enormous (they are interned once) |

### Regression

| # | row | expect |
|---|---|---|
| C1 | Send a message | Normal, ticks normal |
| C2 | Receive one in an open chat | Appears live |
| C3 | A payment card, a file card, an app invite | All render |
| C4 | The group leave that broke last session (#797) | Still leaves cleanly |
| C5 | The three form pages (add contact, add app, create) | Still present at onload (#766) |

---

## §5 · If something is wrong

- **A conversation opened blank** → the pair of `attach` lines and the `batch` line for that
  open. The `n=` says whether the history crossed.
- **A conversation is one pick behind** (theme, language, size) → which pick, and whether a
  `warm drop why=` line is near it.
- **The chats list got janky** → §3 row 4. That number decides whether the warm stays where
  it is.
- **A tap did nothing** → the two `attach` lines for it. `why=attach` means the attach threw
  and the fallback ran; anything else is a refusal that should still have opened the chat.

---

## §6 · Commit

`docs/commit-message-session-p.txt`. New files to `git add`:

```
docs/f5-checklist-session-p.md
docs/walk-artifact-session-p.html
docs/commit-message-session-p.txt
docs/handoff-2026-09-06.md
docs/opus-review-brief-session-p.md
docs/opus-review-verdict-session-p.md
docs/next-session-prompt.md
```

`docs/handoff-2026-09-05e.md` and `docs/f5-checklist-session-o.md` move to `docs/archive/`
(git shows renames). Never `git add -A` — CRLF churn on ~116 files.
